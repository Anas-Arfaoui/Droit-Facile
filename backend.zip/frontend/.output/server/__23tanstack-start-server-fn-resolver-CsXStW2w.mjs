//#region node_modules/.nitro/vite/services/ssr/assets/__23tanstack-start-server-fn-resolver-CsXStW2w.js
var manifest = { "acb414e5f66a469bd4e41beeaa82d5336868ae06f921706e202e91f801dc418b": {
	functionName: "summarizeContract_createServerFn_handler",
	importer: () => import("./_ssr/contract-summary.functions-CZyM-zc3.mjs")
} };
async function getServerFnById(id, access) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = serverFnInfo.module ??= await serverFnInfo.importer();
	if (!fnModule) throw new Error("Server function module not resolved for " + id);
	const action = fnModule[serverFnInfo.functionName];
	if (!action) throw new Error("Server function module export not resolved for serverFn ID: " + id);
	return action;
}
//#endregion
export { getServerFnById as t };
