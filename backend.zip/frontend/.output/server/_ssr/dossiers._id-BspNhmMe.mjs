import { Wt as notFound, _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as dossiers } from "./demo-data-CCg1wzNz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dossiers._id-BspNhmMe.js
var $$splitComponentImporter = () => import("./dossiers._id-D1qlfESq.mjs");
var Route = createFileRoute("/dossiers/$id")({
	loader: ({ params }) => {
		const d = dossiers.find((x) => x.id === params.id);
		if (!d) throw notFound();
		return d;
	},
	head: ({ loaderData }) => ({ meta: [
		{ title: loaderData ? `${loaderData.id} · ${loaderData.client} — Droit-Facile` : "Dossier — Droit-Facile" },
		{
			name: "description",
			content: "Analyse IA du contrat de travail, assistant et résumé à valider."
		},
		{
			property: "og:title",
			content: "Dossier — Droit-Facile"
		},
		{
			property: "og:description",
			content: "Analyse de contrat de travail assistée par IA."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
