import { r as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-DkEpr5mB.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as useI18n, r as useAuth } from "./auth-CNtrPFsd.mjs";
import { _ as EyeOff, f as LockKeyhole, g as Eye, p as LoaderCircle, x as ArrowLeft } from "../_libs/lucide-react.mjs";
import { a as registerAccount, n as Button, t as AppHeader } from "./AppHeader-Bhb_Wo_g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-BWLCtCTQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AuthPage() {
	const { l } = useI18n();
	const { user } = useAuth();
	const navigate = useNavigate();
	const [mode, setMode] = (0, import_react.useState)("login");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const [visible, setVisible] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [message, setMessage] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (user) navigate({
			to: "/",
			replace: true
		});
	}, [user, navigate]);
	const changeMode = (next) => {
		setMode(next);
		setError("");
		setMessage("");
	};
	async function submit(event) {
		event.preventDefault();
		setBusy(true);
		setError("");
		setMessage("");
		try {
			if (mode === "signup") {
				if (await registerAccount(email, password, name, window.location.origin) === "confirm-email") setMessage(l({
					fr: "Consultez votre e-mail pour confirmer votre compte avant de vous connecter.",
					ar: "تحقق من بريدك الإلكتروني لتأكيد حسابك قبل تسجيل الدخول."
				}));
			} else if (mode === "forgot") {
				const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${window.location.origin}/reset-password` });
				if (error) throw error;
				setMessage(l({
					fr: "Si un compte correspond à cette adresse, vous recevrez un lien pour réinitialiser votre mot de passe.",
					ar: "إذا كان هناك حساب بهذا البريد، ستصلك رسالة لإعادة تعيين كلمة المرور."
				}));
			} else {
				const { error } = await supabase.auth.signInWithPassword({
					email,
					password
				});
				if (error) throw error;
			}
		} catch (err) {
			const code = err && typeof err === "object" && "code" in err ? err.code : "";
			setError(code === "email_not_confirmed" ? l({
				fr: "Confirmez votre adresse e-mail avant de vous connecter.",
				ar: "أكد بريدك الإلكتروني قبل تسجيل الدخول."
			}) : mode === "login" ? l({
				fr: "Connexion impossible. Vérifiez votre e-mail et votre mot de passe.",
				ar: "تعذر الدخول. تحقق من بريدك وكلمة المرور."
			}) : l({
				fr: "La demande a échoué. Vérifiez les informations et réessayez dans quelques instants.",
				ar: "تعذر إتمام الطلب. تحقق من المعلومات وحاول لاحقاً."
			}));
		} finally {
			setBusy(false);
		}
	}
	const title = mode === "signup" ? l({
		fr: "Créer un compte",
		ar: "إنشاء حساب"
	}) : mode === "forgot" ? l({
		fr: "Mot de passe oublié",
		ar: "نسيت كلمة المرور"
	}) : l({
		fr: "Connexion",
		ar: "تسجيل الدخول"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto max-w-sm px-5 py-12 sm:py-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockKeyhole, { className: "mb-5 h-8 w-8 text-primary" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 font-serif text-xl text-primary",
					children: l({
						fr: "Droit-Facile",
						ar: "القانون الميسّر"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mb-8 text-3xl",
					children: title
				}),
				mode !== "forgot" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "my-6 flex items-center gap-3 text-xs text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-border" }),
						l({
							fr: "ou par e-mail",
							ar: "أو بالبريد الإلكتروني"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-border" })
					]
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: submit,
					className: "space-y-5",
					children: [
						mode === "signup" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-medium",
							children: [l({
								fr: "Nom complet",
								ar: "الاسم الكامل"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								autoComplete: "name",
								maxLength: 120,
								value: name,
								onChange: (e) => setName(e.target.value),
								className: "mt-2 h-11 w-full rounded-md border border-input bg-card px-3 outline-none focus:ring-2 focus:ring-ring"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-medium",
							children: [l({
								fr: "Adresse e-mail",
								ar: "البريد الإلكتروني"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								type: "email",
								autoComplete: "email",
								value: email,
								onChange: (e) => setEmail(e.target.value),
								dir: "ltr",
								className: "mt-2 h-11 w-full rounded-md border border-input bg-card px-3 outline-none focus:ring-2 focus:ring-ring"
							})]
						}),
						mode !== "forgot" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-medium",
							children: [l({
								fr: "Mot de passe",
								ar: "كلمة المرور"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative mt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									required: true,
									type: visible ? "text" : "password",
									autoComplete: mode === "signup" ? "new-password" : "current-password",
									value: password,
									onChange: (e) => setPassword(e.target.value),
									className: "h-11 w-full rounded-md border border-input bg-card ps-3 pe-12 outline-none focus:ring-2 focus:ring-ring"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "ghost",
									size: "icon",
									className: "absolute end-1 top-1",
									"aria-label": l(visible ? {
										fr: "Masquer le mot de passe",
										ar: "إخفاء كلمة المرور"
									} : {
										fr: "Afficher le mot de passe",
										ar: "إظهار كلمة المرور"
									}),
									onClick: () => setVisible(!visible),
									children: visible ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, {})
								})]
							})]
						}),
						mode === "login" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "link",
							className: "h-auto p-0",
							onClick: () => changeMode("forgot"),
							children: l({
								fr: "Mot de passe oublié ?",
								ar: "نسيت كلمة المرور؟"
							})
						}),
						error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							role: "alert",
							className: "text-sm text-destructive",
							children: error
						}),
						message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							role: "status",
							className: "text-sm text-success",
							children: message
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							className: "h-11 w-full",
							disabled: busy,
							children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }), mode === "forgot" ? l({
								fr: "Envoyer le lien",
								ar: "إرسال الرابط"
							}) : mode === "signup" ? title : l({
								fr: "Se connecter",
								ar: "دخول"
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 text-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "link",
						onClick: () => changeMode(mode === "login" ? "signup" : "login"),
						children: mode === "login" ? l({
							fr: "Créer un compte",
							ar: "إنشاء حساب"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "rtl:rotate-180" }), l({
							fr: "Retour à la connexion",
							ar: "العودة إلى تسجيل الدخول"
						})] })
					})
				})
			]
		})]
	});
}
//#endregion
export { AuthPage as component };
