import { r as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-DkEpr5mB.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as useI18n } from "./auth-CNtrPFsd.mjs";
import { n as Button, t as AppHeader } from "./AppHeader-Bhb_Wo_g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reset-password-OSv7-HDB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ResetPassword() {
	const { l } = useI18n();
	const [password, setPassword] = (0, import_react.useState)("");
	const [confirmation, setConfirmation] = (0, import_react.useState)("");
	const [recovery, setRecovery] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [done, setDone] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const marker = new URLSearchParams(window.location.hash.slice(1)).get("type") === "recovery" || sessionStorage.getItem("df-recovery") === "true";
		if (marker) sessionStorage.setItem("df-recovery", "true");
		supabase.auth.getUser().then(({ data }) => setRecovery(marker && !!data.user));
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto max-w-sm px-5 py-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mb-8 text-3xl",
				children: l({
					fr: "Nouveau mot de passe",
					ar: "كلمة مرور جديدة"
				})
			}), done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "status",
				className: "text-success",
				children: l({
					fr: "Votre mot de passe a été modifié.",
					ar: "تم تغيير كلمة المرور."
				})
			}) : !recovery ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted-foreground",
				children: l({
					fr: "Ouvrez le lien de réinitialisation reçu par e-mail. S’il a expiré, demandez un nouveau lien depuis la connexion.",
					ar: "افتح رابط إعادة التعيين الذي وصلك عبر البريد. إذا انتهت صلاحيته، اطلب رابطاً جديداً من صفحة الدخول."
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "space-y-5",
				onSubmit: async (event) => {
					event.preventDefault();
					setError("");
					if (password !== confirmation) {
						setError(l({
							fr: "Les mots de passe ne correspondent pas.",
							ar: "كلمتا المرور غير متطابقتين."
						}));
						return;
					}
					setBusy(true);
					const { error } = await supabase.auth.updateUser({ password });
					setBusy(false);
					if (error) setError(l({
						fr: "Impossible de modifier le mot de passe. Essayez un mot de passe plus fort ou demandez un nouveau lien.",
						ar: "تعذر تغيير كلمة المرور. جرّب كلمة أقوى أو اطلب رابطاً جديداً."
					}));
					else {
						setDone(true);
						sessionStorage.removeItem("df-recovery");
					}
				},
				children: [
					[{
						label: l({
							fr: "Nouveau mot de passe",
							ar: "كلمة مرور جديدة"
						}),
						value: password,
						set: setPassword
					}, {
						label: l({
							fr: "Confirmer le mot de passe",
							ar: "تأكيد كلمة المرور"
						}),
						value: confirmation,
						set: setConfirmation
					}].map((field) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm",
						children: [field.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							required: true,
							type: "password",
							autoComplete: "new-password",
							value: field.value,
							onChange: (e) => field.set(e.target.value),
							className: "mt-2 h-11 w-full rounded-md border border-input bg-card px-3"
						})]
					}, field.label)),
					error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						role: "alert",
						className: "text-sm text-destructive",
						children: error
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: busy,
						className: "w-full",
						children: l({
							fr: "Enregistrer",
							ar: "حفظ"
						})
					})
				]
			})]
		})]
	});
}
//#endregion
export { ResetPassword as component };
