import { r as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { Bt as isRedirect, x as useRouter, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as useI18n } from "./auth-CNtrPFsd.mjs";
import { a as Send, b as BookOpen, h as FileText, i as Sparkles, p as LoaderCircle, r as Upload, v as Copy, x as ArrowLeft, y as Check } from "../_libs/lucide-react.mjs";
import { i as LevelBadge, t as AppHeader } from "./AppHeader-Bhb_Wo_g.mjs";
import { a as TSS_SERVER_FUNCTION, l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
import { t as getServerFnById } from "../__23tanstack-start-server-fn-resolver-CsXStW2w.mjs";
import { i as fallbackAnswer, n as clauses, o as summary, t as cannedAnswers } from "./demo-data-CCg1wzNz.mjs";
import { t as Route } from "./dossiers._id-BspNhmMe.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dossiers._id-D1qlfESq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useServerFn(serverFn) {
	const router = useRouter();
	return import_react.useCallback(async (...args) => {
		try {
			const res = await serverFn(...args);
			if (isRedirect(res)) throw res;
			return res;
		} catch (err) {
			if (isRedirect(err)) {
				err.options._fromLocation = router.stores.location.get();
				return router.navigate(router.resolveRedirect(err).options);
			}
			throw err;
		}
	}, [router, serverFn]);
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var summarizeContract = createServerFn({ method: "POST" }).inputValidator((input) => {
	if (!input.text?.trim()) throw new Error("Texte du contrat vide");
	return {
		name: String(input.name).slice(0, 200),
		text: String(input.text).slice(0, 6e4),
		lang: input.lang === "ar" ? "ar" : "fr"
	};
}).handler(createSsrRpc("acb414e5f66a469bd4e41beeaa82d5336868ae06f921706e202e91f801dc418b"));
function DossierPage() {
	const d = Route.useLoaderData();
	const { t, l } = useI18n();
	const [tab, setTab] = (0, import_react.useState)("analysis");
	const [state, setState] = (0, import_react.useState)(d.step >= 2 ? "done" : "idle");
	const [validated, setValidated] = (0, import_react.useState)(d.step >= 3);
	const [shared, setShared] = (0, import_react.useState)(d.step >= 3);
	const [contracts, setContracts] = (0, import_react.useState)([]);
	const run = () => {
		setState("loading");
		setTimeout(() => setState("done"), 1800);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto max-w-6xl px-5 py-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4 rtl:rotate-180" }),
						" ",
						t("back")
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap items-end justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs text-muted-foreground",
							children: d.id
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-3xl",
							children: d.client
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-muted-foreground",
							children: l(d.title)
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full bg-secondary px-3 py-1 text-sm",
						children: l(d.status)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 rounded-md border-s-4 border-accent bg-accent/10 px-4 py-2 text-sm",
					children: t("ruleBanner")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "mt-6 flex gap-1 overflow-x-auto border-b border-border",
					children: [
						"analysis",
						"chat",
						"summary",
						"sharing"
					].map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setTab(k),
						className: `whitespace-nowrap border-b-2 px-4 py-2.5 text-sm font-medium ${tab === k ? "border-primary text-foreground" : "border-transparent text-muted-foreground hover:text-foreground"}`,
						children: t(k)
					}, k))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "py-6",
					children: [
						tab === "analysis" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: state !== "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border-2 border-dashed border-border bg-card p-10 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "mx-auto h-8 w-8 text-muted-foreground" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 font-medium",
									children: t("upload")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted-foreground",
									children: d.contract || "contrat.pdf"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: run,
									disabled: state === "loading",
									className: "mt-5 inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground disabled:opacity-70",
									children: [state === "loading" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-4 w-4" }), state === "loading" ? t("analyzing") : t("analyze")]
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-4 flex flex-wrap items-center gap-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "h-4 w-4 text-muted-foreground" }),
								" ",
								d.contract || "contrat.pdf",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-muted px-2.5 py-0.5 text-xs",
									children: t("draft")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ms-auto flex gap-2",
									children: [
										"risk",
										"warn",
										"ok"
									].map((lv) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LevelBadge, { level: lv }),
											" ",
											clauses.filter((c) => c.level === lv).length
										]
									}, lv))
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-3 md:grid-cols-2",
							children: clauses.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "rounded-lg border border-border bg-card p-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
											className: "text-lg",
											children: [
												i + 1,
												". ",
												l(c.title)
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LevelBadge, { level: c.level })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm italic text-muted-foreground",
										children: l(c.excerpt)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm",
										children: l(c.note)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-3 flex items-center gap-1 text-xs text-muted-foreground",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "h-3 w-3" }),
											" ",
											c.law
										]
									})
								]
							}, i))
						})] }) }),
						tab === "chat" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chat, {}),
						tab === "summary" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "max-w-3xl rounded-lg border border-border bg-card p-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `rounded-full px-2.5 py-0.5 text-xs font-medium ${validated ? "bg-success/15 text-success" : "bg-muted"}`,
									children: validated ? t("validated") : t("draft")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 leading-relaxed",
									children: l(summary)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-6 flex flex-wrap gap-2",
									children: [!validated && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setValidated(true),
										className: "inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }),
											" ",
											t("validate")
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => window.print(),
										disabled: !validated,
										className: "rounded-md border border-input px-4 py-2 text-sm disabled:opacity-50",
										children: t("exportPdf")
									})]
								})
							]
						}),
						tab === "summary" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Contracts, {
							contracts,
							setContracts
						}),
						tab === "sharing" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "max-w-3xl space-y-4",
							children: [
								contracts.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg border border-border bg-card p-5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex items-center gap-3 text-sm",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "checkbox",
												disabled: !c.validated,
												checked: c.shared && c.validated,
												onChange: (e) => setContracts((cs) => cs.map((x) => x.id === c.id ? {
													...x,
													shared: e.target.checked
												} : x)),
												className: "h-4 w-4 accent-primary"
											}),
											t("share"),
											" — ",
											c.name
										]
									}), !c.validated && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-xs text-destructive",
										children: t("needValidate")
									})]
								}, c.id)),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg border border-border bg-card p-5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-medium",
											children: t("shareLink")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-2 flex items-center gap-2 rounded-md bg-muted px-3 py-2 font-mono text-sm",
											dir: "ltr",
											children: [
												"/suivi/",
												d.token,
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "ms-auto h-4 w-4 text-muted-foreground" })
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/suivi/$token",
											params: { token: d.token },
											className: "mt-3 inline-block text-sm text-primary underline",
											children: t("viewClient")
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg border border-border bg-card p-5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex items-center gap-3 text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "checkbox",
											disabled: !validated,
											checked: shared && validated,
											onChange: (e) => setShared(e.target.checked),
											className: "h-4 w-4 accent-primary"
										}), t("shareSummary")]
									}), !validated && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-xs text-destructive",
										children: t("needValidate")
									})]
								})
							]
						})
					]
				})
			]
		})]
	});
}
function Chat() {
	const { t, l } = useI18n();
	const [msgs, setMsgs] = (0, import_react.useState)([]);
	const [q, setQ] = (0, import_react.useState)("");
	const ask = (e) => {
		e.preventDefault();
		if (!q.trim()) return;
		const low = q.toLowerCase();
		const a = cannedAnswers.find((c) => c.keys.some((k) => low.includes(k)))?.a ?? fallbackAnswer;
		const idx = msgs.length;
		setMsgs((m) => [...m, { q }]);
		setQ("");
		setTimeout(() => setMsgs((m) => m.map((x, i) => i === idx ? {
			...x,
			a
		} : x)), 900);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex max-w-3xl flex-col rounded-lg border border-border bg-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-h-72 space-y-4 p-5",
			children: [msgs.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: l({
					fr: "Essayez : « La période d'essai est-elle légale ? »",
					ar: "جرّب: « هل فترة التجربة قانونية؟ »"
				})
			}), msgs.map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "ms-auto w-fit max-w-[85%] rounded-lg bg-primary px-3 py-2 text-sm text-primary-foreground",
					children: m.q
				}), m.a ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-fit max-w-[85%] rounded-lg bg-muted px-3 py-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: l(m.a.text) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 flex items-center gap-1 border-t border-border pt-2 text-xs text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "h-3 w-3" }),
							" ",
							t("source"),
							" : ",
							l(m.a.source)
						]
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin text-muted-foreground" })]
			}, i))]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: ask,
			className: "flex gap-2 border-t border-border p-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: q,
				onChange: (e) => setQ(e.target.value),
				placeholder: t("ask"),
				className: "flex-1 rounded-md border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				className: "inline-flex items-center gap-1 rounded-md bg-primary px-3 py-2 text-sm text-primary-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "h-4 w-4 rtl:-scale-x-100" }),
					" ",
					t("send")
				]
			})]
		})]
	});
}
function Contracts({ contracts, setContracts }) {
	const { t, lang } = useI18n();
	const summarize = useServerFn(summarizeContract);
	const [name, setName] = (0, import_react.useState)("");
	const [text, setText] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [err, setErr] = (0, import_react.useState)("");
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [draft, setDraft] = (0, import_react.useState)("");
	const update = (id, p) => setContracts((cs) => cs.map((c) => c.id === id ? {
		...c,
		...p
	} : c));
	const onFile = async (f) => {
		if (!f) return;
		setText(await f.text());
		if (!name) setName(f.name);
	};
	const add = async (e) => {
		e.preventDefault();
		if (!text.trim() || busy) return;
		setBusy(true);
		setErr("");
		try {
			const r = await summarize({ data: {
				name: name || "contrat",
				text,
				lang
			} });
			if ("error" in r && r.error) setErr(r.error);
			else if ("summary" in r && r.summary) {
				setContracts((cs) => [{
					id: crypto.randomUUID(),
					name: name || "contrat",
					summary: r.summary,
					validated: false,
					shared: false
				}, ...cs]);
				setName("");
				setText("");
			}
		} catch {
			setErr("Le résumé n'a pas pu être généré.");
		}
		setBusy(false);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-8 max-w-3xl space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xl",
				children: t("contracts")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: add,
				className: "space-y-3 rounded-lg border border-border bg-card p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: t("addContract")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: name,
						onChange: (e) => setName(e.target.value),
						placeholder: t("contractName"),
						className: "w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: text,
						onChange: (e) => setText(e.target.value),
						placeholder: t("contractText"),
						rows: 6,
						className: "w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: ".txt,text/plain",
							onChange: (e) => onFile(e.target.files?.[0]),
							className: "text-sm"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							disabled: busy || !text.trim(),
							className: "ms-auto inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground disabled:opacity-60",
							children: [
								busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-4 w-4" }),
								" ",
								busy ? t("summarizing") : t("generate")
							]
						})]
					}),
					err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-destructive",
						children: err
					})
				]
			}),
			contracts.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: t("noContracts")
			}),
			contracts.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-lg border border-border bg-card p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "h-4 w-4 text-muted-foreground" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-medium",
								children: c.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `ms-auto rounded-full px-2.5 py-0.5 text-xs font-medium ${c.validated ? "bg-success/15 text-success" : "bg-muted"}`,
								children: c.validated ? t("validated") : t("draft")
							})
						]
					}),
					editing === c.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: draft,
						onChange: (e) => setDraft(e.target.value),
						rows: 6,
						className: "mt-3 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 whitespace-pre-line text-sm leading-relaxed",
						children: c.summary
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [editing === c.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								update(c.id, {
									summary: draft,
									validated: false,
									shared: false
								});
								setEditing(null);
							},
							className: "rounded-md border border-input px-3 py-1.5 text-sm",
							children: t("save")
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								setDraft(c.summary);
								setEditing(c.id);
							},
							className: "rounded-md border border-input px-3 py-1.5 text-sm",
							children: t("edit")
						}), !c.validated && editing !== c.id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => update(c.id, { validated: true }),
							className: "inline-flex items-center gap-1 rounded-md bg-primary px-3 py-1.5 text-sm font-medium text-primary-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }),
								" ",
								t("validate")
							]
						})]
					})
				]
			}, c.id))
		]
	});
}
//#endregion
export { DossierPage as component };
