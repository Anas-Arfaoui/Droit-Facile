import { r as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-DkEpr5mB.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { x as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { r as useQueryClient } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-CNtrPFsd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var dict = {
	app: {
		fr: "Droit-Facile",
		ar: "القانون الميسّر"
	},
	tagline: {
		fr: "Cabinet Ben Salah & Associés",
		ar: "مكتب بن صالح وشركاؤه"
	},
	dossiers: {
		fr: "Dossiers",
		ar: "الملفات"
	},
	newDossier: {
		fr: "Nouveau dossier",
		ar: "ملف جديد"
	},
	search: {
		fr: "Rechercher un client ou un dossier…",
		ar: "ابحث عن حريف أو ملف…"
	},
	client: {
		fr: "Client",
		ar: "الحريف"
	},
	status: {
		fr: "État",
		ar: "الحالة"
	},
	updated: {
		fr: "Mis à jour",
		ar: "آخر تحديث"
	},
	open: {
		fr: "Ouvrir",
		ar: "فتح"
	},
	ruleBanner: {
		fr: "L'IA aide, l'avocat décide. Toute réponse de l'IA est un brouillon.",
		ar: "الذكاء الاصطناعي يساعد، والمحامي يقرّر. كل إجابة هي مسودة."
	},
	analysis: {
		fr: "Analyse du contrat",
		ar: "تحليل العقد"
	},
	chat: {
		fr: "Assistant",
		ar: "المساعد"
	},
	summary: {
		fr: "Résumé",
		ar: "الملخّص"
	},
	sharing: {
		fr: "Partage client",
		ar: "مشاركة مع الحريف"
	},
	upload: {
		fr: "Importer un contrat de travail",
		ar: "استيراد عقد شغل"
	},
	analyze: {
		fr: "Lancer l'analyse IA",
		ar: "إطلاق التحليل"
	},
	analyzing: {
		fr: "Analyse en cours…",
		ar: "جارٍ التحليل…"
	},
	draft: {
		fr: "Brouillon IA",
		ar: "مسودة آلية"
	},
	validated: {
		fr: "Validé par l'avocat",
		ar: "مصادق عليه من المحامي"
	},
	validate: {
		fr: "Valider le résumé",
		ar: "المصادقة على الملخّص"
	},
	exportPdf: {
		fr: "Exporter en PDF",
		ar: "تصدير PDF"
	},
	ask: {
		fr: "Posez une question…",
		ar: "اطرح سؤالا…"
	},
	send: {
		fr: "Envoyer",
		ar: "إرسال"
	},
	source: {
		fr: "Source",
		ar: "المصدر"
	},
	ok: {
		fr: "Conforme",
		ar: "مطابق"
	},
	warn: {
		fr: "À vérifier",
		ar: "للتثبت"
	},
	risk: {
		fr: "Risque",
		ar: "خطر"
	},
	shareLink: {
		fr: "Lien sécurisé du client",
		ar: "رابط آمن للحريف"
	},
	shareSummary: {
		fr: "Partager le résumé validé",
		ar: "مشاركة الملخّص المصادق عليه"
	},
	needValidate: {
		fr: "Validez d'abord le résumé pour pouvoir le partager.",
		ar: "صادق على الملخّص أولاً لتتمكن من مشاركته."
	},
	viewClient: {
		fr: "Voir la page client",
		ar: "عرض صفحة الحريف"
	},
	timeline: {
		fr: "Suivi du dossier",
		ar: "متابعة الملف"
	},
	sharedDocs: {
		fr: "Documents partagés",
		ar: "الوثائق المشاركة"
	},
	nothingShared: {
		fr: "Aucun document partagé pour l'instant.",
		ar: "لا توجد وثائق مشاركة حالياً."
	},
	clientHello: {
		fr: "Bonjour",
		ar: "مرحباً"
	},
	demo: {
		fr: "Démo — données fictives",
		ar: "عرض تجريبي — بيانات وهمية"
	},
	contracts: {
		fr: "Contrats du dossier",
		ar: "عقود الملف"
	},
	addContract: {
		fr: "Ajouter un contrat",
		ar: "إضافة عقد"
	},
	contractName: {
		fr: "Nom du contrat",
		ar: "اسم العقد"
	},
	contractText: {
		fr: "Collez le texte du contrat ou importez un fichier .txt",
		ar: "الصق نص العقد أو استورد ملف ‎.txt"
	},
	generate: {
		fr: "Ajouter et résumer",
		ar: "إضافة وتلخيص"
	},
	summarizing: {
		fr: "Rédaction du résumé…",
		ar: "جارٍ كتابة الملخّص…"
	},
	noContracts: {
		fr: "Aucun nouveau contrat ajouté.",
		ar: "لم تتم إضافة أي عقد جديد."
	},
	edit: {
		fr: "Modifier",
		ar: "تعديل"
	},
	save: {
		fr: "Enregistrer",
		ar: "حفظ"
	},
	share: {
		fr: "Partager avec le client",
		ar: "مشاركة مع الحريف"
	},
	back: {
		fr: "Retour",
		ar: "رجوع"
	}
};
var I18n = (0, import_react.createContext)(null);
function I18nProvider({ children }) {
	const [lang, setLang] = (0, import_react.useState)("fr");
	(0, import_react.useEffect)(() => {
		const s = localStorage.getItem("df-lang");
		if (s === "ar" || s === "fr") setLang(s);
	}, []);
	(0, import_react.useEffect)(() => {
		document.documentElement.lang = lang;
		document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
		localStorage.setItem("df-lang", lang);
	}, [lang]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(I18n.Provider, {
		value: {
			lang,
			setLang,
			t: (k) => dict[k][lang],
			l: (v) => v[lang]
		},
		children
	});
}
function useI18n() {
	const c = (0, import_react.useContext)(I18n);
	if (!c) throw new Error("I18nProvider missing");
	return c;
}
var AuthContext = (0, import_react.createContext)({
	user: null,
	loading: true
});
function AuthProvider({ children }) {
	const [user, setUser] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const router = useRouter();
	const queryClient = useQueryClient();
	(0, import_react.useEffect)(() => {
		if (new URLSearchParams(window.location.hash.slice(1)).get("type") === "recovery") sessionStorage.setItem("df-recovery", "true");
		let active = true;
		let revision = 0;
		const refresh = () => {
			const current = ++revision;
			supabase.auth.getUser().then(({ data }) => {
				if (active && current === revision) {
					setUser(data.user);
					setLoading(false);
				}
			}).catch(() => {
				if (active && current === revision) {
					setUser(null);
					setLoading(false);
				}
			});
		};
		const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
			if (event === "PASSWORD_RECOVERY") sessionStorage.setItem("df-recovery", "true");
			if (event === "SIGNED_OUT") sessionStorage.removeItem("df-recovery");
			if (![
				"SIGNED_IN",
				"SIGNED_OUT",
				"USER_UPDATED",
				"PASSWORD_RECOVERY"
			].includes(event)) return;
			if (event === "SIGNED_OUT") {
				++revision;
				setUser(null);
				setLoading(false);
			} else queueMicrotask(refresh);
			router.invalidate();
			if (event !== "SIGNED_OUT") queryClient.invalidateQueries();
		});
		refresh();
		return () => {
			active = false;
			subscription.unsubscribe();
		};
	}, [router, queryClient]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthContext.Provider, {
		value: {
			user,
			loading
		},
		children
	});
}
var useAuth = () => (0, import_react.useContext)(AuthContext);
//#endregion
export { useI18n as i, I18nProvider as n, useAuth as r, AuthProvider as t };
