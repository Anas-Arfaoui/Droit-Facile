import { a as TSS_SERVER_FUNCTION, l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
import { t as createOpenAI } from "../_libs/@ai-sdk/openai+[...].mjs";
import { t as streamText } from "../_libs/ai.mjs";
import processModule from "node:process";
//#region node_modules/.nitro/vite/services/ssr/assets/contract-summary.functions-CZyM-zc3.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var summarizeContract_createServerFn_handler = createServerRpc({
	id: "acb414e5f66a469bd4e41beeaa82d5336868ae06f921706e202e91f801dc418b",
	name: "summarizeContract",
	filename: "src/lib/contract-summary.functions.ts"
}, (opts) => summarizeContract.__executeServer(opts));
var summarizeContract = createServerFn({ method: "POST" }).inputValidator((input) => {
	if (!input.text?.trim()) throw new Error("Texte du contrat vide");
	return {
		name: String(input.name).slice(0, 200),
		text: String(input.text).slice(0, 6e4),
		lang: input.lang === "ar" ? "ar" : "fr"
	};
}).handler(summarizeContract_createServerFn_handler, async ({ data }) => {
	const key = processModule.env["LOVABLE_API_KEY"];
	if (!key) return { error: "Configuration IA manquante." };
	let runId;
	const openai = createOpenAI({
		baseURL: "https://ai.gateway.lovable.dev/v1",
		apiKey: key,
		headers: {
			"Lovable-API-Key": key,
			"X-Lovable-AIG-SDK": "vercel-ai-sdk"
		},
		fetch: async (input, init) => {
			const h = new Headers(init?.headers);
			if (runId) h.set("X-Lovable-AIG-Run-ID", runId);
			const r = await fetch(input, {
				...init,
				headers: h
			});
			runId ??= r.headers.get("X-Lovable-AIG-Run-ID") ?? void 0;
			return r;
		}
	});
	let failure;
	try {
		const text = (await streamText({
			model: openai.responses("openai/gpt-6-astra"),
			maxRetries: 0,
			system: (data.lang === "ar" ? "اكتب بالعربية. " : "Rédige en français. ") + "Tu aides un avocat. Résume le contrat en 4 à 6 phrases courtes : nature du contrat, parties, durée, rémunération, et les clauses qui semblent problématiques. Pas de conseil définitif : c'est un brouillon que l'avocat validera. Texte brut, sans titres ni listes.",
			prompt: `Contrat « ${data.name} » :\n\n${data.text}`,
			onError: ({ error }) => {
				failure = error;
			},
			providerOptions: { openai: {
				forceReasoning: true,
				reasoningEffort: "low",
				store: false,
				include: ["reasoning.encrypted_content"]
			} }
		}).text).trim();
		if (failure || !text) throw failure ?? /* @__PURE__ */ new Error("empty");
		return { summary: text };
	} catch (e) {
		const status = e?.statusCode;
		console.error("summarizeContract failed", status, e);
		if (status === 402) return { error: "Crédits IA épuisés. Ajoutez des crédits pour continuer." };
		if (status === 429) return { error: "Trop de demandes, réessayez dans un instant." };
		return { error: "Le résumé n'a pas pu être généré." };
	}
});
//#endregion
export { summarizeContract_createServerFn_handler };
