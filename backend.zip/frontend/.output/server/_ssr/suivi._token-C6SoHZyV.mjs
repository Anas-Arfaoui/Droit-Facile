import { Wt as notFound, _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as dossiers } from "./demo-data-CCg1wzNz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/suivi._token-C6SoHZyV.js
var $$splitComponentImporter = () => import("./suivi._token-CyB1Rqn_.mjs");
var Route = createFileRoute("/suivi/$token")({
	loader: ({ params }) => {
		const d = dossiers.find((x) => x.token === params.token);
		if (!d) throw notFound();
		return d;
	},
	head: () => ({ meta: [
		{ title: "Suivi de votre dossier — Droit-Facile" },
		{
			name: "description",
			content: "Consultez l'état de votre dossier et les documents partagés par votre avocat."
		},
		{
			property: "og:title",
			content: "Suivi de votre dossier — Droit-Facile"
		},
		{
			property: "og:description",
			content: "Suivi sécurisé de votre dossier."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		},
		{
			name: "robots",
			content: "noindex"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
