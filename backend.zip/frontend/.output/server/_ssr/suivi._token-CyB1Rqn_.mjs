import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as useI18n } from "./auth-CNtrPFsd.mjs";
import { d as Lock, h as FileText, y as Check } from "../_libs/lucide-react.mjs";
import { r as LangSwitch } from "./AppHeader-Bhb_Wo_g.mjs";
import { a as steps, o as summary } from "./demo-data-CCg1wzNz.mjs";
import { t as Route } from "./suivi._token-C6SoHZyV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/suivi._token-CyB1Rqn_.js
var import_jsx_runtime = require_jsx_runtime();
function Suivi() {
	const d = Route.useLoaderData();
	const { t, l } = useI18n();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "bg-sidebar text-sidebar-foreground",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-2xl items-center justify-between px-5 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "h-4 w-4" }),
						" ",
						t("tagline")
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LangSwitch, {})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto max-w-2xl px-5 py-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-muted-foreground",
					children: [t("clientHello"), ","]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl",
					children: d.client
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-muted-foreground",
					children: [
						l(d.title),
						" · ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs",
							children: d.id
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-10 text-xl",
					children: t("timeline")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-4 space-y-4",
					children: steps.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `grid h-7 w-7 place-items-center rounded-full text-xs ${i <= d.step ? "bg-primary text-primary-foreground" : "border border-border text-muted-foreground"}`,
							children: i < d.step ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }) : i + 1
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: i <= d.step ? "font-medium" : "text-muted-foreground",
							children: l(s)
						})]
					}, i))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-10 text-xl",
					children: t("sharedDocs")
				}),
				d.step >= 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 rounded-lg border border-border bg-card p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex items-center gap-2 text-sm font-medium",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "h-4 w-4" }),
							" ",
							t("summary"),
							" — ",
							t("validated")
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed",
						children: l(summary)
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-muted-foreground",
					children: t("nothingShared")
				})
			]
		})]
	});
}
//#endregion
export { Suivi as component };
