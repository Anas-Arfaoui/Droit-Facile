//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BtJMPYNy.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/msi/Desktop/lawyer-up/frontend/src/routes/__root.tsx",
		children: [
			"/",
			"/auth",
			"/reset-password",
			"/dossiers/$id",
			"/suivi/$token"
		],
		preloads: [
			"/assets/index-B66AlFCD.js",
			"/assets/rolldown-runtime-CbXtAM7H.js",
			"/assets/auth-w0vcin4S.js",
			"/assets/preload-helper-B3OpD0zl.js",
			"/assets/demo-data-CrUpeOcM.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B66AlFCD.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/msi/Desktop/lawyer-up/frontend/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CQPWNp8x.js", "/assets/AppHeader-CWqR4hif.js"]
	},
	"/auth": {
		filePath: "C:/Users/msi/Desktop/lawyer-up/frontend/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-C6M3BqnZ.js",
			"/assets/AppHeader-CWqR4hif.js",
			"/assets/loader-circle-BIuEZRYX.js"
		]
	},
	"/reset-password": {
		filePath: "C:/Users/msi/Desktop/lawyer-up/frontend/src/routes/reset-password.tsx",
		children: void 0,
		preloads: ["/assets/reset-password-o6jMOuxX.js", "/assets/AppHeader-CWqR4hif.js"]
	},
	"/dossiers/$id": {
		filePath: "C:/Users/msi/Desktop/lawyer-up/frontend/src/routes/dossiers.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/dossiers._id-D_GsS4Qz.js",
			"/assets/AppHeader-CWqR4hif.js",
			"/assets/loader-circle-BIuEZRYX.js",
			"/assets/file-text-pkfm0Yts.js"
		]
	},
	"/suivi/$token": {
		filePath: "C:/Users/msi/Desktop/lawyer-up/frontend/src/routes/suivi.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/suivi._token-DhZ6SuJi.js",
			"/assets/AppHeader-CWqR4hif.js",
			"/assets/file-text-pkfm0Yts.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
